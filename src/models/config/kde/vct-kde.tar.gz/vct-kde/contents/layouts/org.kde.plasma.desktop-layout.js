var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1920x1080": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "725",
                    "DialogWidth": "1455"
                },
                "/Wallpaper/luisbocanegra.smart.video.wallpaper.reborn/General": {
                    "LastVideo": "file:///home/vicit/Development/Projects/dotfiles/files/assets/wallpapers/bg-mov-01.mp4",
                    "VideoUrls": "[{\"filename\":\"file:///home/vicit/Development/Projects/dotfiles/files/assets/wallpapers/bg-mov-01.mp4\",\"enabled\":true,\"duration\":0,\"customDuration\":0,\"playbackRate\":0,\"alternativePlaybackRate\":0,\"loop\":false}]"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "file:///usr/share/wallpapers/SafeLanding/",
                    "SlidePaths": "/home/vicit/.local/share/wallpapers/,/usr/share/wallpapers/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "509",
                            "popupWidth": "872"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "alphaSort": "true",
                            "applicationsDisplay": "0",
                            "favoritesPortedToKAstats": "true",
                            "icon": "preferences-system-linux",
                            "primaryActions": "3",
                            "showActionButtonCaptions": "false",
                            "switchCategoryOnHover": "true",
                            "systemFavorites": "lock-screen\\,logout\\,save-session\\,switch-user\\,suspend\\,hibernate\\,reboot\\,shutdown"
                        }
                    },
                    "plugin": "org.kde.plasma.kickoff"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/General": {
                            "launchers": "preferred://filemanager,preferred://browser,applications:code.desktop,applications:figma-linux.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "451",
                            "popupWidth": "810"
                        },
                        "/Appearance": {
                            "customDateFormat": "ddd dd MMMM yyyy -",
                            "dateDisplayFormat": "BesideTime",
                            "dateFormat": "custom",
                            "enabledCalendarPlugins": "alternatecalendar,astronomicalevents,holidaysevents,pimevents",
                            "firstDayOfWeek": "1",
                            "showSeconds": "Always",
                            "showWeekNumbers": "true",
                            "use24hFormat": "2"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 1.7777777777777777,
            "hiding": "dodgewindows",
            "lengthMode": "fill",
            "location": "top",
            "maximumLength": 65.33333333333333,
            "minimumLength": 65.33333333333333,
            "offset": 0,
            "opacity": "adaptive"
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
