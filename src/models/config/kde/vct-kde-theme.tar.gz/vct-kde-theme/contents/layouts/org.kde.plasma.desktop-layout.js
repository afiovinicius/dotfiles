var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1920x1080": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "725",
                    "DialogWidth": "1455"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "file:///usr/share/wallpapers/Patak/",
                    "SlidePaths": "/,\\,,h,\\,,o,\\,,m,\\,,e,\\,,/,\\,,v,\\,,i,\\,,c,\\,,i,\\,,t,\\,,/,\\,,.,\\,,l,\\,,o,\\,,c,\\,,a,\\,,l,\\,,/,\\,,s,\\,,h,\\,,a,\\,,r,\\,,e,\\,,/,\\,,w,\\,,a,\\,,l,\\,,l,\\,,p,\\,,a,\\,,p,\\,,e,\\,,r,\\,,s,\\,,/,\\,,\\\\,\\,,\\,,/,\\,,u,\\,,s,\\,,r,\\,,/,\\,,s,\\,,h,\\,,a,\\,,r,\\,,e,\\,,/,\\,,w,\\,,a,\\,,l,\\,,l,\\,,p,\\,,a,\\,,p,\\,,e,\\,,r,\\,,s,\\,,/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "509",
                            "popupWidth": "872"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "alphaSort": "true",
                            "applicationsDisplay": "0",
                            "favoritesPortedToKAstats": "true",
                            "icon": "preferences-system-linux",
                            "primaryActions": "3",
                            "showActionButtonCaptions": "false",
                            "switchCategoryOnHover": "true",
                            "systemFavorites": "lock-screen\\,logout\\,save-session\\,switch-user\\,suspend\\,hibernate\\,reboot\\,shutdown"
                        }
                    },
                    "plugin": "org.kde.plasma.kickoff"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/General": {
                            "launchers": ""
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "451",
                            "popupWidth": "810"
                        },
                        "/Appearance": {
                            "customDateFormat": "ddd dd MMMM yyyy -",
                            "dateDisplayFormat": "BesideTime",
                            "dateFormat": "custom",
                            "enabledCalendarPlugins": "alternatecalendar,astronomicalevents,holidaysevents,pimevents",
                            "firstDayOfWeek": "1",
                            "showSeconds": "Always",
                            "showWeekNumbers": "true",
                            "use24hFormat": "2"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 2,
            "hiding": "dodgewindows",
            "lengthMode": "fill",
            "location": "top",
            "maximumLength": 64,
            "minimumLength": 64,
            "offset": 0,
            "opacity": "adaptive"
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
